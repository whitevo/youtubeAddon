I have uploaded the source code in bitbucket and github:
https://github.com/whitevo/youtubeAddon.git
git clone https://whitevo@bitbucket.org/whitevo/youtube-addon.git